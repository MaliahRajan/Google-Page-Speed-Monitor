// Firebase Admin Config
const admin = require('firebase-admin');
const serviceAccount = require('./pagespeed-monitor-ffb69-firebase-adminsdk-4c23o-ffa37d35d8.json');
const fs = require('fs');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// Page Speed Config
const pagespeed = require('gpagespeed')

async function getPageSpeedScores() {
    const brandConfigs = db.collection('Brand_Config').doc('MW_Food');
    const date = new Date().toDateString();
    const brandMarkets = await brandConfigs.listCollections();
    brandMarkets.forEach(async(market) => {
        const brandDoc = await market.get();
        brandDoc.forEach(async(brandDocData) => { 
            const data = brandDocData.data();
            Object.values(data).map((pageUrl,index) => {
                const options = {
                    url: pageUrl,
                    strategy: 'MOBILE',
                    key: 'AIzaSyA-tGEOcdMPLyEBnlB52a4DyxWgJgkZbD8'
                }
                
                pagespeed(options)
                .then(async(response) => {
                    await db.collection('Page_Speed_Results').doc('MW_Food').collection(date).doc(market.id).collection(Object.keys(data)[index]).doc('Mobile').set({
                       score: parseInt(response.lighthouseResult.categories.performance.score * 100),
                       performanceAuditRef: response.lighthouseResult.categories.performance.auditRefs,
                       networkRequest: response.lighthouseResult.audits['network-requests'],
                       screenShot: response.lighthouseResult.audits['final-screenshot'],
                       timeStamp: response.analysisUTCTimestamp
                    });

                    const options = {
                        url: pageUrl,
                        key: 'AIzaSyA-tGEOcdMPLyEBnlB52a4DyxWgJgkZbD8'
                    }
                    
                    pagespeed(options)
                    .then(async(response) => {
                        await db.collection('Page_Speed_Results').doc('MW_Food').collection(date).doc(market.id).collection(Object.keys(data)[index]).doc('Desktop').set({
                           score: parseInt(response.lighthouseResult.categories.performance.score * 100),
                           performanceAuditRef: response.lighthouseResult.categories.performance.auditRefs,
                           networkRequest: response.lighthouseResult.audits['network-requests'],
                           screenShot: response.lighthouseResult.audits['final-screenshot'],
                           timeStamp: response.analysisUTCTimestamp
                        });
                    })
                    .catch(error => {
                        console.error(error)
                    })

                })
                .catch(error => {
                    console.error(error)
                })
            });
        });
    });
    // console.log(snapshot);
    // const pageSpeedData = {};
    // snapshot.forEach(async(doc) => {
    //     console.log(doc);
    //     console.log(doc.id, '=>', doc.data());
    //     const data = doc.data();
    
    // });
}

async function setSiteInformation() {
    const ukMarket = {
        bensoriginal: 'http://uk.bensoriginal.com',
        twix: 'https://twix.co.uk',
        galaxy: 'https://www.galaxychocolate.co.uk'
    };

    const usMarket = {
        bensoriginal: 'https://www.bensoriginal.com',
        twix: 'https://www.twix.com',
        dove: 'https://www.dovechocolate.com'
    };
    
    await db.collection('Brand_Config').doc('MW_Food').collection('US').doc().set(usMarket);
    const res =  await db.collection('Brand_Config').doc('MW_Food').collection('UK').doc().set(ukMarket);
    return res;
}
//setSiteInformation();
const pageSpeedData = getPageSpeedScores();
//const cities = await get();
//console.log(pageSpeedData);